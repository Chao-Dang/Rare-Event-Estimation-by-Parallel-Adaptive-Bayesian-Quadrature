clearvars; close all;clc



%% Define the input of the model
Xinput.Dim = 2;
Xinput.Dist = {'Normal','Normal'}; 
Xinput.Mean = [0,0];
Xinput.Std = [1,1];

% the parameters of the random variables
for i = 1:Xinput.Dim
    switch Xinput.Dist{i}
        case 'Normal'
            Xinput.Para(1,i) = Xinput.Mean(i);
            Xinput.Para(2,i) = Xinput.Std(i);
        case 'Lognormal'
            Xinput.Para(1,i) = log((Xinput.Mean(i)^2)/sqrt(Xinput.Std(i)^2+Xinput.Mean(i)^2));
            Xinput.Para(2,i) = sqrt(log(Xinput.Std(i)^2/(Xinput.Mean(i)^2)+1));
        otherwise
            disp('Check your distribution type!')
    end
end

%% Define the performance function

% specity the paremeter
a = 3;
b = 6;
% specify the performance function
Per_Fun = @(x) min([a + 0.1.*(x(:,1)-x(:,2)).^2 - (x(:,1)+x(:,2))./sqrt(2), a + 0.1*(x(:,1)-x(:,2)).^2 + (x(:,1)+x(:,2))./sqrt(2), (x(:,1) - x(:,2)) + b./sqrt(2), (x(:,2) - x(:,1)) + b./sqrt(2)],[],2);


%% Monte Carlo Simulation (MCS)
% MCS.Size = 1E8;  % the number of samples used in MCS
% 
% % genertate simple random samples
% for j = 1:Xinput.Dim
%     switch Xinput.Dist{j}
%         case 'Normal'
%              MCS.Sample(:,j) = normrnd(Xinput.Para(1,j),Xinput.Para(2,j),MCS.Size,1);
%         case 'Lognormal'
%              MCS.Sample(:,j) = lognrnd(Xinput.Para(1,j),Xinput.Para(2,j),MCS.Size,1);
%         otherwise
%             disp('Check your distribution type!')
%     end
% end
% 
% 
% % evaluate the performance function
% Y = Per_Fun(MCS.Sample);
% % assess the failure proabability
% Pf_mcs = length(find(Y<=0))./MCS.Size;
% Pf_mcs_cov = sqrt((1-Pf_mcs)./(Pf_mcs.*MCS.Size));


%% Proposed PABQ��parallel adaptive Bayesian quadrature
N_cluster = 5; % number of points selected in each iteration
N_pop = 1e6;   % number of samples in the ball importance sampling
R = 6.0;       % radius of the ball
kesi = 0.10;   % threshold for the stopping criterion

[PABQ_Result] = Parallel_Adaptive_Bayesian_Quadrature(Xinput,Per_Fun,N_cluster,N_pop,R,kesi);




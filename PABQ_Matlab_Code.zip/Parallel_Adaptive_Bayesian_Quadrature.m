function [PABQ_Result] = Parallel_Adaptive_Bayesian_Quadrature(Xinput,Per_Fun,N_cluster,N_pop,R,kesi)
%PARALLEL_ADAPTIVE_KRIGING_COMBINED_WITH_CE_IS_N 
%   cast the problem in standard normal space

%% Generate N_pop candidate samples
dim = Xinput.Dim;


% Generate N_pop uniformly distributed samples in a ball with ridius R
N_candid = Ball_Sampling(N_pop,dim,R);  % uniform samples in ball


%% Initial DOE
N0 = 10;

X0 = N_candid(1:N0,:);



Y0 = Per_Fun(Standard_normal_to_X(X0,Xinput));


% Joint PDF for X
Pdf = @(x) mvnpdf(x,zeros(1,dim),eye(dim));

k = 1;
Delayed_num = 1;

while true
    % ardsquaredexponential matern52
    % train or update the Gaussian process regression model
    GPRmodel = fitrgp(X0,Y0,'BasisFunction','constant','KernelFunction','ardsquaredexponential','Standardize',1,'ConstantSigma',true,'Sigma',1e-12,'SigmaLowerBound',1e-12); %
    
    % GPR prediction
    ypmu = @(x) prediction_mean(GPRmodel,x);
    ypstd = @(x) prediction_std(GPRmodel,x);

    V_n = pi.^(dim/2)*R^(dim)./(gamma(dim/2+1));
    Pf = @(x) V_n.*mean(normcdf(-ypmu(x)./ypstd(x)).*Pdf(x));
    Upstd = @(x)  V_n.*mean(sqrt(normcdf(ypmu(x)./ypstd(x)).*normcdf(-ypmu(x)./ypstd(x))).*Pdf(x));

    Ratio(k) = Upstd(N_candid)./Pf(N_candid);
    Ratio(max(end-Delayed_num+1,1):end)
    
    % stopping criterion
    if  (k>=Delayed_num) && (sum(Ratio(end-Delayed_num+1:end)<=kesi) == Delayed_num)
        break;
    end
    
    W_fun = @(x) sqrt(normcdf(-(ypmu(x))./ypstd(x)).*normcdf((ypmu(x))./ypstd(x))).*Pdf(x);  % normcdf(-abs(ypmu(x))./ypstd(x)).*Pdf(x)
    weight = W_fun(N_candid);
    
   C = K_weighted_means_for_PABQ(N_candid, N_cluster, weight);
    X_add = C;
    Y_add = Per_Fun(Standard_normal_to_X(X_add,Xinput));
    X0 = [X0;X_add];
    Y0 = [Y0;Y_add];
    k = k+1;
    fprintf('PABQ: %d samples \n',N0+(k-1).*N_cluster)
    
end



PABQ_Result.Pf = Pf(N_candid);
PABQ_Result.X = X0;
PABQ_Result.N = N0+(k-1).*N_cluster;

end

function [ymu] = prediction_mean(GPRmodel,x)
ymu = predict(GPRmodel,x);
end

function [yst] = prediction_std(GPRmodel,x)
[~,yst] = predict(GPRmodel,x);
end



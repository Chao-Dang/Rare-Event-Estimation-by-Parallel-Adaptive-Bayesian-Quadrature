function [Xsample] = Standard_normal_to_X(Usample,Xinput)
% U_TO_X transformation of samples in standard normal sapce to the physical
% space
 dim = Xinput.Dim ;

%  tansform the samples in standard normal space of aleatory
% parameters to the physical space
for j = 1:dim
    switch Xinput.Dist{j}
        case 'Normal'
            Xsample(:,j) = Xinput.Para(1,j)+Xinput.Para(2,j).*Usample(:,j);
        case 'Uniform'
           Xsample(:,j) = unifinv(normcdf(Usample(:,j)),Xinput.Para(1,j),Xinput.Para(2,j)); 
        case 'Lognormal'
           Xsample(:,j) = logninv(normcdf(Usample(:,j)),Xinput.Para(1,j),Xinput.Para(2,j)); 
        otherwise
            disp('Check your distribution type!')
    end
end





end


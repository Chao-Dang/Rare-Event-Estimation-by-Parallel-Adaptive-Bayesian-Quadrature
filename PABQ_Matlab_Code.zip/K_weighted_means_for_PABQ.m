function [Centroids] = K_weighted_means_for_PABQ(X, K, Weights)
%K_WEIGHTED_MEANS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

Num = size(X,1);

% Initilal randomly select centroids
Centroids = X(randsample(Num,K),:);


r = 1;
Kesi = 0.001;
while true
%     fprintf('Clustering start!\n')
    SED = pdist2(X,Centroids);   % squared Euclidean distance ,'squaredeuclidean'
    
    
     [~,Label]= min(SED,[],2);
    
    for k = 1:K
        Temp(k,:) = ((Weights(find(Label==k))).^1)'*X(find(Label==k),:)./sum((Weights(find(Label==k))).^1);      % weighted mean
    end
    
%     Error = norm(Centroids-Temp);
    if r >= 15
        break;      
    end
    r = r + 1;
    
    Centroids = Temp;
%     fprintf('Clustering finish!\n')

    clear Label SED Temp
end

end

